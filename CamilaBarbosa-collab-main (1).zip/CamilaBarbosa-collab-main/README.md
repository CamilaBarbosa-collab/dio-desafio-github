- 👋 Hi, I’m @CamilaBarbosa-collab
- 👀 I’m interested in learning Python, DS, AI, C programming etc.
- 🌱 I’m currently learning C# and Python
- 💞️ I’m looking to collaborate on fun projects!
- 📫 How to reach me: at https://www.instagram.com/camila_moba/

<!---
Repositório criado para projetos de bootcamp da DIO
--->
